# Mosquito > 2025-12-27 8:23pm
https://universe.roboflow.com/nijum-barua-ogglt/mosquito-6vtkg-stkkw

Provided by a Roboflow user
License: CC BY 4.0

